@echo off
cd Debug
start /min %~dp0\Release\SmartDots.exe
exit 0
